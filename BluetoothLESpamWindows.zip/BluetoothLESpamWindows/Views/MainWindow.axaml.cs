using Avalonia.Controls;

namespace BluetoothLESpamWindows.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}