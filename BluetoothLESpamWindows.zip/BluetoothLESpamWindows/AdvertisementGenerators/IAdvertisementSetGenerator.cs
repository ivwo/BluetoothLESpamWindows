using BluetoothLESpamWindows.Models;

namespace BluetoothLESpamWindows.AdvertisementGenerators
{
    public interface IAdvertisementSetGenerator
    {
        AdvertisementSet GenerateAdvertisementSet();
    }
}