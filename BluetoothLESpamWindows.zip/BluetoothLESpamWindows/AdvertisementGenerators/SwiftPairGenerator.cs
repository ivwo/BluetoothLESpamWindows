using System;
using System.Collections.Generic;
using BluetoothLESpamWindows.Models;

namespace BluetoothLESpamWindows.AdvertisementGenerators
{
    public class SwiftPairGenerator : IAdvertisementSetGenerator
    {
        public AdvertisementSet GenerateAdvertisementSet()
        {
            var advertisementSet = new AdvertisementSet(
                "Microsoft Swift Pair",
                "Generates Swift Pair pop-ups on Windows devices"
            );
            
            // Add different Swift Pair devices
            AddSwiftPairHeadphones(advertisementSet);
            AddSwiftPairSpeaker(advertisementSet);
            AddSwiftPairKeyboard(advertisementSet);
            AddSwiftPairMouse(advertisementSet);
            
            return advertisementSet;
        }
        
        private void AddSwiftPairHeadphones(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x0006, // Microsoft
                ManufacturerData = new byte[] 
                {
                    0x03, // Swift Pair
                    0x01, // Headphones
                    0x01, 0x02, 0x03, 0x04, 0x05, 0x06 // Model ID (random)
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
        
        private void AddSwiftPairSpeaker(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x0006, // Microsoft
                ManufacturerData = new byte[] 
                {
                    0x03, // Swift Pair
                    0x02, // Speaker
                    0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F // Model ID (random)
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
        
        private void AddSwiftPairKeyboard(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x0006, // Microsoft
                ManufacturerData = new byte[] 
                {
                    0x03, // Swift Pair
                    0x03, // Keyboard
                    0x11, 0x22, 0x33, 0x44, 0x55, 0x66 // Model ID (random)
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
        
        private void AddSwiftPairMouse(AdvertisementSet advertisementSet)
        {
            var advertisementData = new AdvertisementData
            {
                ManufacturerId = 0x0006, // Microsoft
                ManufacturerData = new byte[] 
                {
                    0x03, // Swift Pair
                    0x04, // Mouse
                    0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF // Model ID (random)
                }
            };
            
            advertisementSet.AdvertisementDataList.Add(advertisementData);
        }
    }
}