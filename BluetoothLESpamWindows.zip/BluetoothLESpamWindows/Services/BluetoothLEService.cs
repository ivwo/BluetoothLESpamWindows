using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using BluetoothLESpamWindows.Models;
using InTheHand.Bluetooth;

namespace BluetoothLESpamWindows.Services
{
    public class BluetoothLEService
    {
        private readonly List<AdvertisementSet> _advertisementSets = new List<AdvertisementSet>();
        private CancellationTokenSource? _cancellationTokenSource;
        private int _txPowerLevel = -7; // Default value
        private BluetoothLEAdvertisementPublisher? _publisher;
        
        public BluetoothLEService()
        {
        }
        
        public void AddAdvertisementSet(AdvertisementSet advertisementSet)
        {
            _advertisementSets.Add(advertisementSet);
        }
        
        public List<AdvertisementSet> GetAdvertisementSets()
        {
            return _advertisementSets;
        }
        
        public void SetTxPowerLevel(int txPowerLevel)
        {
            _txPowerLevel = txPowerLevel;
        }
        
        public int GetTxPowerLevel()
        {
            return _txPowerLevel;
        }
        
        public async Task StartAdvertising(AdvertisementSet advertisementSet, CancellationToken cancellationToken)
        {
            try
            {
                // Check if Bluetooth is available
                if (!await Bluetooth.GetAvailabilityAsync())
                {
                    throw new Exception("Bluetooth is not available on this device");
                }
                
                // Start advertising each advertisement in the set
                foreach (var advertisementData in advertisementSet.AdvertisementDataList)
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        break;
                    }
                    
                    await AdvertiseData(advertisementData);
                    
                    // Wait for the specified interval
                    await Task.Delay(advertisementSet.IntervalMilliseconds, cancellationToken);
                }
            }
            catch (TaskCanceledException)
            {
                // Task was canceled, do nothing
            }
            catch (Exception ex)
            {
                // Handle exceptions
                Console.WriteLine($"Error advertising: {ex.Message}");
            }
        }
        
        private async Task AdvertiseData(AdvertisementData advertisementData)
        {
            try
            {
                // Create a new advertisement publisher
                _publisher = new BluetoothLEAdvertisementPublisher();
                
                // Set local name if available
                if (!string.IsNullOrEmpty(advertisementData.LocalName))
                {
                    _publisher.Advertisement.LocalName = advertisementData.LocalName;
                }
                
                // Set manufacturer data if available
                if (advertisementData.ManufacturerData != null && advertisementData.ManufacturerData.Length > 0)
                {
                    var manufacturerData = new BluetoothLEManufacturerData(
                        advertisementData.ManufacturerId,
                        advertisementData.ManufacturerData
                    );
                    
                    _publisher.Advertisement.ManufacturerData.Add(manufacturerData);
                }
                
                // Set service UUID if available
                if (advertisementData.ServiceUuid != Guid.Empty)
                {
                    _publisher.Advertisement.ServiceUuids.Add(advertisementData.ServiceUuid);
                }
                
                // Set TX power level
                _publisher.Advertisement.TxPowerLevel = _txPowerLevel;
                
                // Start advertising
                _publisher.Start();
                
                // Wait a short time to ensure the advertisement is sent
                await Task.Delay(100);
                
                // Stop advertising
                _publisher.Stop();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in AdvertiseData: {ex.Message}");
            }
        }
        
        public void StartAdvertisingLoop(AdvertisementSet advertisementSet)
        {
            // Cancel any existing advertising
            StopAdvertising();
            
            // Create a new cancellation token source
            _cancellationTokenSource = new CancellationTokenSource();
            
            // Start the advertising loop
            Task.Run(async () =>
            {
                try
                {
                    for (int i = 0; i < advertisementSet.RepeatCount || advertisementSet.RepeatCount <= 0; i++)
                    {
                        if (_cancellationTokenSource.Token.IsCancellationRequested)
                        {
                            break;
                        }
                        
                        await StartAdvertising(advertisementSet, _cancellationTokenSource.Token);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error in advertising loop: {ex.Message}");
                }
            });
        }
        
        public void StopAdvertising()
        {
            if (_publisher != null)
            {
                _publisher.Stop();
                _publisher = null;
            }
            
            if (_cancellationTokenSource != null)
            {
                _cancellationTokenSource.Cancel();
                _cancellationTokenSource.Dispose();
                _cancellationTokenSource = null;
            }
        }
    }
    
    // Mock classes for compilation - these would be replaced by actual Windows APIs in a real Windows environment
    public class BluetoothLEAdvertisementPublisher
    {
        public BluetoothLEAdvertisement Advertisement { get; } = new BluetoothLEAdvertisement();
        
        public void Start()
        {
            Console.WriteLine("Starting advertisement...");
        }
        
        public void Stop()
        {
            Console.WriteLine("Stopping advertisement...");
        }
    }
    
    public class BluetoothLEAdvertisement
    {
        public string? LocalName { get; set; }
        public List<Guid> ServiceUuids { get; } = new List<Guid>();
        public List<BluetoothLEManufacturerData> ManufacturerData { get; } = new List<BluetoothLEManufacturerData>();
        public int? TxPowerLevel { get; set; }
    }
    
    public class BluetoothLEManufacturerData
    {
        public ushort CompanyId { get; }
        public byte[] Data { get; }
        
        public BluetoothLEManufacturerData(ushort companyId, byte[] data)
        {
            CompanyId = companyId;
            Data = data;
        }
    }
}