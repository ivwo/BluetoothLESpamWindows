using System;
using System.Collections.Generic;
using BluetoothLESpamWindows.AdvertisementGenerators;
using BluetoothLESpamWindows.Models;

namespace BluetoothLESpamWindows.Services
{
    public class AdvertisementSetService
    {
        private readonly List<IAdvertisementSetGenerator> _generators = new List<IAdvertisementSetGenerator>();
        private readonly List<AdvertisementSet> _advertisementSets = new List<AdvertisementSet>();
        
        public AdvertisementSetService()
        {
            // Register all advertisement generators
            RegisterGenerators();
            
            // Generate all advertisement sets
            GenerateAdvertisementSets();
        }
        
        private void RegisterGenerators()
        {
            _generators.Add(new AppleDevicePopUpGenerator());
            _generators.Add(new SwiftPairGenerator());
            // Add more generators as needed
        }
        
        private void GenerateAdvertisementSets()
        {
            foreach (var generator in _generators)
            {
                var advertisementSet = generator.GenerateAdvertisementSet();
                _advertisementSets.Add(advertisementSet);
            }
        }
        
        public List<AdvertisementSet> GetAdvertisementSets()
        {
            return _advertisementSets;
        }
        
        public AdvertisementSet? GetAdvertisementSetByName(string name)
        {
            return _advertisementSets.Find(set => set.Name == name);
        }
    }
}