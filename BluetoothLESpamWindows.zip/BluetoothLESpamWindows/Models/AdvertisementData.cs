using System;
using System.Collections.Generic;

namespace BluetoothLESpamWindows.Models
{
    public class AdvertisementData
    {
        public Guid ServiceUuid { get; set; }
        public byte[]? ManufacturerData { get; set; }
        public ushort ManufacturerId { get; set; }
        public Dictionary<string, byte[]> ServiceData { get; set; } = new Dictionary<string, byte[]>();
        public string? LocalName { get; set; }
        public int TxPowerLevel { get; set; } = -7; // Default value
        
        public AdvertisementData()
        {
        }
    }
}