using System;
using System.Collections.Generic;

namespace BluetoothLESpamWindows.Models
{
    public class AdvertisementSet
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public List<AdvertisementData> AdvertisementDataList { get; set; } = new List<AdvertisementData>();
        public int RepeatCount { get; set; } = 1;
        public int IntervalMilliseconds { get; set; } = 200;
        
        public AdvertisementSet()
        {
        }
        
        public AdvertisementSet(string name, string description)
        {
            Name = name;
            Description = description;
        }
    }
}