﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia.Threading;
using BluetoothLESpamWindows.Models;
using BluetoothLESpamWindows.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace BluetoothLESpamWindows.ViewModels
{
    public partial class MainWindowViewModel : ViewModelBase
    {
        private readonly BluetoothLEService _bluetoothService;
        private readonly AdvertisementSetService _advertisementSetService;
        
        [ObservableProperty]
        private ObservableCollection<AdvertisementSet> _advertisementSets;
        
        [ObservableProperty]
        private AdvertisementSet? _selectedAdvertisementSet;
        
        [ObservableProperty]
        private string _statusMessage = "Ready";
        
        [ObservableProperty]
        private bool _isAdvertising = false;
        
        [ObservableProperty]
        private int _txPowerLevel = -7;
        
        [ObservableProperty]
        private int _intervalMilliseconds = 200;
        
        [ObservableProperty]
        private int _repeatCount = 1;
        
        public MainWindowViewModel()
        {
            _bluetoothService = new BluetoothLEService();
            _advertisementSetService = new AdvertisementSetService();
            
            // Initialize advertisement sets
            AdvertisementSets = new ObservableCollection<AdvertisementSet>(_advertisementSetService.GetAdvertisementSets());
            
            // Set default selected advertisement set
            if (AdvertisementSets.Count > 0)
            {
                SelectedAdvertisementSet = AdvertisementSets[0];
            }
        }
        
        [RelayCommand]
        private void StartAdvertising()
        {
            if (SelectedAdvertisementSet == null)
            {
                StatusMessage = "No advertisement set selected";
                return;
            }
            
            try
            {
                // Update the selected advertisement set with current settings
                SelectedAdvertisementSet.IntervalMilliseconds = IntervalMilliseconds;
                SelectedAdvertisementSet.RepeatCount = RepeatCount;
                
                // Set TX power level
                _bluetoothService.SetTxPowerLevel(TxPowerLevel);
                
                // Start advertising
                _bluetoothService.StartAdvertisingLoop(SelectedAdvertisementSet);
                
                IsAdvertising = true;
                StatusMessage = $"Advertising: {SelectedAdvertisementSet.Name}";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error: {ex.Message}";
            }
        }
        
        [RelayCommand]
        private void StopAdvertising()
        {
            _bluetoothService.StopAdvertising();
            IsAdvertising = false;
            StatusMessage = "Advertising stopped";
        }
        
        [RelayCommand]
        private void SelectAdvertisementSet(AdvertisementSet advertisementSet)
        {
            SelectedAdvertisementSet = advertisementSet;
            StatusMessage = $"Selected: {advertisementSet.Name}";
        }
    }
}
