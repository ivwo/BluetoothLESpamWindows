﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace BluetoothLESpamWindows.ViewModels;

public class ViewModelBase : ObservableObject
{
}
