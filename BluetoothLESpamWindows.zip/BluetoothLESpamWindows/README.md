# Bluetooth LE Spam for Windows

This is a Windows port of the [Bluetooth LE Spam](https://github.com/simondankelmann/Bluetooth-LE-Spam) Android application. It allows you to send Bluetooth Low Energy advertisements that can trigger various notifications on nearby devices.

## Features

- Send Apple device pop-up advertisements (AirPods, AirTags, etc.)
- Send Microsoft Swift Pair advertisements
- Customize TX power level, interval, and repeat count
- Simple and intuitive user interface

## Requirements

- Windows 10 or later
- Bluetooth 4.0+ adapter with Low Energy support
- .NET 8.0 Runtime (included in the standalone executable)

## Installation

1. Download the latest release
2. Extract the ZIP file to a location of your choice
3. Run `BluetoothLESpam.exe`

No installation is required as the application is portable and self-contained.

## Usage

1. Select an advertisement set from the list on the left
2. Adjust the settings as needed:
   - TX Power Level: Controls the transmission power (higher values increase range)
   - Interval (ms): Time between advertisements
   - Repeat Count: Number of times to repeat the advertisement sequence
3. Click "Start" to begin advertising
4. Click "Stop" to end advertising

## Building from Source

### Prerequisites

- .NET 8.0 SDK or later
- Visual Studio 2022 or later (optional)

### Build Steps

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/BluetoothLESpamWindows.git
   cd BluetoothLESpamWindows
   ```

2. Build the project:
   ```
   dotnet build
   ```

3. Run the application:
   ```
   dotnet run
   ```

4. Create a standalone executable:
   ```
   dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:PublishReadyToRun=true
   ```
   The executable will be located in `bin\Release\net8.0\win-x64\publish\BluetoothLESpam.exe`

## Disclaimer

This application is provided for educational and research purposes only. Use responsibly and ethically. Do not use this application to disrupt or annoy others. The developers are not responsible for any misuse of this software.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [Simon Dankelmann](https://github.com/simondankelmann) for the original Android application
- [InTheHand.BluetoothLE](https://github.com/inthehand/32feet) for the Bluetooth LE library
- All contributors to the original project